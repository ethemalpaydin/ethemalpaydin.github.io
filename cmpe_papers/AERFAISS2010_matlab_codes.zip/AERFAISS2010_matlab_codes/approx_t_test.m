% approx t test
% E Alpaydin
p=0.2;
N=100;
K=100;
KK=10;
rp=[]; xp=[];
for p0=0.05:0.05:0.95;
    j=0;
    for t=1:K    
        for l=1:KK
   		% generate sample
			for t=1:N
   			r=rand;
      		if r<p x(l,t)=1; else x(l,t)=0; end
        end;
      	e(l)=sum(x(l,:))/N;   
   	end;
   	m=mean(e);
   	s=std(e);
   	t=sqrt(KK)*(m-p0)/s;
    if (t>1.83) j=j+1; end;
   end;
   fprintf('H0: %4.2f <= %4.2f: Reject prob %6.4f \n',p,p0,j/K);
 	xp=[xp p0];
 	rp=[rp j/K];
end
plot(xp,rp);
title('t test');
ylabel('Prob of Rejecting 0.2<p'); xlabel('p');
   
   
