% Approximate normal test
% E Alpaydin
p=0.2;
N=20;
K=100;
rp=[]; xp=[];
for p0=0.05:0.05:0.95;
    j=0;
    for t=1:K
        % generate sample
        for t=1:N
            r=rand;
            if r<p x(t)=1; else x(t)=0; end   
        end
        %
        e=sum(x);
        m=N*p0;
        s=sqrt(N*p0*(1-p0));
        z=(e-m)/s;
        if (z>1.6449) j=j+1; end;
    end;
    fprintf('H0: %4.2f <= %4.2f: Reject prob %6.4f \n',p,p0,j/K);
    xp=[xp p0];
    rp=[rp j/K];
end
plot(xp,rp);
title('Approximate normal test');
ylabel('Prob of Rejecting 0.2<p'); xlabel('p');


   
   
