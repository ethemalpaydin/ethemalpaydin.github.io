% Binomial test
% E Alpaydin
p=0.2;
N=100;
K=100;
rp=[]; xp=[];
for p0=0.05:0.05:1.0;
    j=0;
    for r=1:K
        % generate sample
        for t=1:N
            r=rand;
            if r<p x(t)=1; else x(t)=0; end
        end
        %	
        e=sum(x);
        a=0; 
        for k=e:N
            b=(prod(N-k+1:N)/prod(1:k))*(p0^k)*((1-p0)^(N-k));
            a=a+b;
        end;
        if (a<0.05) j=j+1; end;
    end;
    fprintf('H0: %4.2f <= %4.2f: Reject prob %6.4f \n',p,p0,j/K);
    xp=[xp p0];
    rp=[rp j/K];
end
plot(xp,rp);
title('Binomial test');
ylabel('Prob of Rejecting 0.2<p'); xlabel('p');

   
   
