% paired t test
% E Alpaydin
p=0.25;
N=100;
K=30;
T=100;
rp=[]; xp=[]; op=[];
for p0=0.05:0.05:0.95;
    j=0;
    for r=1:T    
      for l=1:K
   		% generate two samples one with p and one with p_0
			for t=1:N
                r=rand;
                if r<p x(l,t)=1; else x(l,t)=0; end
            end;
			for t=1:N
                r=rand;
                if r<p0 x2(l,t)=1; else x2(l,t)=0; end
            end;
            e(l)=sum(x(l,:))/N-sum(x2(l,:))/N;   
        end;
        m=mean(e);
        s=std(e);
        t=sqrt(K)*(m-0)/s;
%        if (abs(t)>2.05) j=j+1; end;
        if (t<-2.25) j=j+1; end;
    end;
    fprintf('H0: %4.2f = %4.2f: Reject prob %6.4f \n',p,p0,j/T);
 	xp=[xp p0];
 	rp=[rp j/T];
end
plot(xp,rp);
title('paired t test');
ylabel('Prob of Rejecting p=0.5'); xlabel('p');

   
   
