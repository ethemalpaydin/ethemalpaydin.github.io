% nonparametric sign t test
% E Alpaydin
p=0.3;
N=100;
K=30;
T=100;
rp=[]; xp=[]; op=[];
for p0=0.05:0.05:0.95;
    j=0;
    for i=1:T    
        for l=1:K
   		% generate two samples one with p and one with p_0
			for t=1:N
                r=rand;
                if r<p x(l,t)=1; else x(l,t)=0; end
            end;
			for t=1:N
                r=rand;
                if r<p0 x2(l,t)=1; else x2(l,t)=0; end
            end;
            if sum(x(l,:))>sum(x2(l,:)) e(l)=1; else e(l)=0; end;   
        end;
        a=0; nw=sum(e(:));
        for k=nw:K
            b=(prod(K-k+1:K)/prod(1:k))*(0.5^k)*((1-0.5)^(K-k));
            a=a+b;
        end;
        if (a<0.05) j=j+1; end;
    end;
    fprintf('H0: %4.2f <= %4.2f: Reject prob %6.4f \n',p,p0,j/T);
 	xp=[xp p0];
 	rp=[rp j/T];
end
plot(xp,rp);
title('nonpar sign test');
ylabel('Prob of Rejecting 0.5<= p'); xlabel('p');

   
   
