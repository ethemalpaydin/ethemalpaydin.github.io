% Draw ROC and PR curves for a 1d problem
% E Alpaydin
clear all;
subplot(2,2,1); hold on;
fplot('0.4/0.3*exp(-(x-2)*(x-2)/(2*0.3*0.3))',[1 4],'--'); 
fplot('0.4/0.3*exp(-(x-3)*(x-3)/(2*0.3*0.3))',[1 4],'-');
%
fplot('(0.4/0.3*exp(-(x-2)*(x-2)/(2*0.3*0.3)))/(0.4/0.3*exp(-(x-2)*(x-2)/(2*0.3*0.3))+0.4/0.3*exp(-(x-3)*(x-3)/(2*0.3*0.3)))',[1 4],'--'); hold on;
fplot('(0.4/0.3*exp(-(x-3)*(x-3)/(2*0.3*0.3)))/(0.4/0.3*exp(-(x-2)*(x-2)/(2*0.3*0.3))+0.4/0.3*exp(-(x-3)*(x-3)/(2*0.3*0.3)))',[1 4],'-'); 
%
N=100;
xp=zeros(N,1); xn=zeros(N,1);
for i=1:N xp(i)=3+(sum(rand(12,1))-6)*0.3; end;
for i=1:N xn(i)=2+(sum(rand(12,1))-6)*0.3; end;
plot(xp(:),0,'b+'); plot(xn(:),0,'ro');
%
L=20;
tp=zeros(L,1); fp=zeros(L,1); fn=zeros(L,1); tn=zeros(L,1);
acc=zeros(L,1); err=zeros(L,1);
tpr=zeros(L,1); fpr=zeros(L,1); prec=zeros(L,1); rec=zeros(L,1);
for i=1:L
    h=2+i/L;
    tp(i)=size(find(xp(:)>=h),1); fp(i)=size(find(xn(:)>=h),1);
    fn(i)=size(find(xp(:)<h),1); tn(i)=size(find(xn(:)<h),1);
    tpr(i)=tp(i)/(tp(i)+fn(i)); fpr(i)=fp(i)/(fp(i)+tn(i));
    prec(i)=tp(i)/(tp(i)+fp(i)); rec(i)=tpr(i);
end;
subplot(2,2,3); axis([0 1 0 1]); hold on; plot(fpr(:),tpr(:),'-'); xlabel('fpr'); ylabel('tpr'); 
subplot(2,2,4); axis([0 1 0 1]); hold on; plot(rec(:),prec(:),'-'); xlabel('recall'); ylabel('precision'); 
